﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_3_take_home
{
    public partial class Form1 : Form
    {
        DataTable dtregis = new DataTable();
        DataTable dtlogin = new DataTable();
        DataTable dtuang = new DataTable(); 
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            pn_kotak2.Visible = false;
        }
        string b = "ayam";
        private void bt_regis2_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < dtregis.Rows.Count; i++)
            {
                if (tb_user2.Text == dtregis.Rows[i].ToString())
                {
                    b = "cacing";
                }
            }
            for (int i = 0; i < dtregis.Columns.Count; i++)
            {
                if (tb_user2.Text == dtregis.Columns[i].ToString())
                {
                    b = "cacing";
                }
            }
            if (b != "cacing")
            {
                dtregis.Columns.Add(tb_user2.Text);
                MessageBox.Show("Register Success");
            }
            else
            {
                MessageBox.Show("Username Has Been Used");
                b = "tsania";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string user2 = tb_user2.Text;
        }

        private void tb_pass2_TextChanged(object sender, EventArgs e)
        {
            string pass = tb_pass2.Text;
        }
        string a = "gajah";
        private void bt_login_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dtlogin.Rows.Count; i++)
            {
                if (tb_user1.Text == dtlogin.Rows[i].ToString())
                {
                    b = "jerapah";
                }
            }
            for (int i = 0; i < dtlogin.Columns.Count; i++)
            {
                if (tb_user2.Text == dtregis.Columns[i].ToString())
                {
                    b = "jerapah";
                }
            }
            if (b != "jerapah")
            {
                dtlogin.Columns.Add(tb_user2.Text);
                MessageBox.Show("Register First");
            }
            else
            {
                MessageBox.Show("Login Success");
                b = "gajah";
            }
        }

        private void bt_regis1_Click(object sender, EventArgs e)
        {
            pn_kotak2.Visible = true;
        }

        private void bt_deposit1_Click(object sender, EventArgs e)
        {
            pn_kotak4.Visible = true;
            pn_kotak3.Visible = false;
        }

        private void tb_uang2_TextChanged(object sender, EventArgs e)
        {
            string n = tb_uang2.Text;
        }

        private void bt_deposit2_Click(object sender, EventArgs e)
        {
            lb_uang1.Text = tb_uang2.Text;
        }
    }
}
