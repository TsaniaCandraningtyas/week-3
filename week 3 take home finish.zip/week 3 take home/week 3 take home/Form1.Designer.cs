﻿namespace week_3_take_home
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_login = new System.Windows.Forms.Button();
            this.tb_pass2 = new System.Windows.Forms.TextBox();
            this.lb_user1 = new System.Windows.Forms.Label();
            this.lb_pass1 = new System.Windows.Forms.Label();
            this.lb_pass2 = new System.Windows.Forms.Label();
            this.lb_user2 = new System.Windows.Forms.Label();
            this.tb_user2 = new System.Windows.Forms.TextBox();
            this.tb_pass1 = new System.Windows.Forms.TextBox();
            this.tb_user1 = new System.Windows.Forms.TextBox();
            this.bt_regis1 = new System.Windows.Forms.Button();
            this.bt_regis2 = new System.Windows.Forms.Button();
            this.pn_kotak1 = new System.Windows.Forms.Panel();
            this.pn_kotak2 = new System.Windows.Forms.Panel();
            this.bt_logout1 = new System.Windows.Forms.Button();
            this.lb_balance = new System.Windows.Forms.Label();
            this.bt_deposit1 = new System.Windows.Forms.Button();
            this.bt_withdraw = new System.Windows.Forms.Button();
            this.bt_deposit2 = new System.Windows.Forms.Button();
            this.tb_uang2 = new System.Windows.Forms.TextBox();
            this.lb_judul = new System.Windows.Forms.Label();
            this.bt_logout2 = new System.Windows.Forms.Button();
            this.pn_kotak3 = new System.Windows.Forms.Panel();
            this.pn_kotak4 = new System.Windows.Forms.Panel();
            this.lb_uang1 = new System.Windows.Forms.Label();
            this.pn_kotak1.SuspendLayout();
            this.pn_kotak3.SuspendLayout();
            this.pn_kotak4.SuspendLayout();
            this.SuspendLayout();
            // 
            // bt_login
            // 
            this.bt_login.Location = new System.Drawing.Point(109, 151);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(75, 23);
            this.bt_login.TabIndex = 0;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = true;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // tb_pass2
            // 
            this.tb_pass2.Location = new System.Drawing.Point(66, 125);
            this.tb_pass2.Name = "tb_pass2";
            this.tb_pass2.Size = new System.Drawing.Size(150, 20);
            this.tb_pass2.TabIndex = 1;
            this.tb_pass2.TextChanged += new System.EventHandler(this.tb_pass2_TextChanged);
            // 
            // lb_user1
            // 
            this.lb_user1.AutoSize = true;
            this.lb_user1.Location = new System.Drawing.Point(12, 106);
            this.lb_user1.Name = "lb_user1";
            this.lb_user1.Size = new System.Drawing.Size(55, 13);
            this.lb_user1.TabIndex = 2;
            this.lb_user1.Text = "Username";
            this.lb_user1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lb_pass1
            // 
            this.lb_pass1.AutoSize = true;
            this.lb_pass1.Location = new System.Drawing.Point(14, 128);
            this.lb_pass1.Name = "lb_pass1";
            this.lb_pass1.Size = new System.Drawing.Size(53, 13);
            this.lb_pass1.TabIndex = 3;
            this.lb_pass1.Text = "Password";
            // 
            // lb_pass2
            // 
            this.lb_pass2.AutoSize = true;
            this.lb_pass2.Location = new System.Drawing.Point(3, 56);
            this.lb_pass2.Name = "lb_pass2";
            this.lb_pass2.Size = new System.Drawing.Size(53, 13);
            this.lb_pass2.TabIndex = 4;
            this.lb_pass2.Text = "Password";
            // 
            // lb_user2
            // 
            this.lb_user2.AutoSize = true;
            this.lb_user2.Location = new System.Drawing.Point(3, 23);
            this.lb_user2.Name = "lb_user2";
            this.lb_user2.Size = new System.Drawing.Size(55, 13);
            this.lb_user2.TabIndex = 5;
            this.lb_user2.Text = "Username";
            // 
            // tb_user2
            // 
            this.tb_user2.Location = new System.Drawing.Point(66, 103);
            this.tb_user2.Name = "tb_user2";
            this.tb_user2.Size = new System.Drawing.Size(150, 20);
            this.tb_user2.TabIndex = 6;
            this.tb_user2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // tb_pass1
            // 
            this.tb_pass1.Location = new System.Drawing.Point(59, 49);
            this.tb_pass1.Name = "tb_pass1";
            this.tb_pass1.Size = new System.Drawing.Size(150, 20);
            this.tb_pass1.TabIndex = 7;
            // 
            // tb_user1
            // 
            this.tb_user1.Location = new System.Drawing.Point(59, 23);
            this.tb_user1.Name = "tb_user1";
            this.tb_user1.Size = new System.Drawing.Size(150, 20);
            this.tb_user1.TabIndex = 8;
            // 
            // bt_regis1
            // 
            this.bt_regis1.Location = new System.Drawing.Point(109, 180);
            this.bt_regis1.Name = "bt_regis1";
            this.bt_regis1.Size = new System.Drawing.Size(75, 23);
            this.bt_regis1.TabIndex = 9;
            this.bt_regis1.Text = "Register";
            this.bt_regis1.UseVisualStyleBackColor = true;
            this.bt_regis1.Click += new System.EventHandler(this.bt_regis1_Click);
            // 
            // bt_regis2
            // 
            this.bt_regis2.Location = new System.Drawing.Point(102, 75);
            this.bt_regis2.Name = "bt_regis2";
            this.bt_regis2.Size = new System.Drawing.Size(75, 23);
            this.bt_regis2.TabIndex = 10;
            this.bt_regis2.Text = "Register";
            this.bt_regis2.UseVisualStyleBackColor = true;
            this.bt_regis2.Click += new System.EventHandler(this.bt_regis2_Click);
            // 
            // pn_kotak1
            // 
            this.pn_kotak1.Controls.Add(this.bt_regis2);
            this.pn_kotak1.Controls.Add(this.tb_user1);
            this.pn_kotak1.Controls.Add(this.tb_pass1);
            this.pn_kotak1.Controls.Add(this.lb_user2);
            this.pn_kotak1.Controls.Add(this.lb_pass2);
            this.pn_kotak1.Location = new System.Drawing.Point(7, 225);
            this.pn_kotak1.Name = "pn_kotak1";
            this.pn_kotak1.Size = new System.Drawing.Size(220, 115);
            this.pn_kotak1.TabIndex = 11;
            // 
            // pn_kotak2
            // 
            this.pn_kotak2.Location = new System.Drawing.Point(7, 55);
            this.pn_kotak2.Name = "pn_kotak2";
            this.pn_kotak2.Size = new System.Drawing.Size(220, 164);
            this.pn_kotak2.TabIndex = 12;
            // 
            // bt_logout1
            // 
            this.bt_logout1.Location = new System.Drawing.Point(393, 64);
            this.bt_logout1.Name = "bt_logout1";
            this.bt_logout1.Size = new System.Drawing.Size(75, 23);
            this.bt_logout1.TabIndex = 13;
            this.bt_logout1.Text = "Log Out";
            this.bt_logout1.UseVisualStyleBackColor = true;
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Location = new System.Drawing.Point(261, 129);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(46, 13);
            this.lb_balance.TabIndex = 14;
            this.lb_balance.Text = "Balance";
            // 
            // bt_deposit1
            // 
            this.bt_deposit1.Location = new System.Drawing.Point(334, 151);
            this.bt_deposit1.Name = "bt_deposit1";
            this.bt_deposit1.Size = new System.Drawing.Size(75, 23);
            this.bt_deposit1.TabIndex = 15;
            this.bt_deposit1.Text = "Deposit";
            this.bt_deposit1.UseVisualStyleBackColor = true;
            this.bt_deposit1.Click += new System.EventHandler(this.bt_deposit1_Click);
            // 
            // bt_withdraw
            // 
            this.bt_withdraw.Location = new System.Drawing.Point(334, 180);
            this.bt_withdraw.Name = "bt_withdraw";
            this.bt_withdraw.Size = new System.Drawing.Size(75, 23);
            this.bt_withdraw.TabIndex = 16;
            this.bt_withdraw.Text = "Withdraw";
            this.bt_withdraw.UseVisualStyleBackColor = true;
            // 
            // bt_deposit2
            // 
            this.bt_deposit2.Location = new System.Drawing.Point(334, 326);
            this.bt_deposit2.Name = "bt_deposit2";
            this.bt_deposit2.Size = new System.Drawing.Size(75, 23);
            this.bt_deposit2.TabIndex = 17;
            this.bt_deposit2.Text = "Deposit";
            this.bt_deposit2.UseVisualStyleBackColor = true;
            this.bt_deposit2.Click += new System.EventHandler(this.bt_deposit2_Click);
            // 
            // tb_uang2
            // 
            this.tb_uang2.Location = new System.Drawing.Point(279, 300);
            this.tb_uang2.Name = "tb_uang2";
            this.tb_uang2.Size = new System.Drawing.Size(189, 20);
            this.tb_uang2.TabIndex = 18;
            this.tb_uang2.TextChanged += new System.EventHandler(this.tb_uang2_TextChanged);
            // 
            // lb_judul
            // 
            this.lb_judul.AutoSize = true;
            this.lb_judul.Location = new System.Drawing.Point(331, 277);
            this.lb_judul.Name = "lb_judul";
            this.lb_judul.Size = new System.Drawing.Size(109, 13);
            this.lb_judul.TabIndex = 19;
            this.lb_judul.Text = "Input Deposit Amount";
            // 
            // bt_logout2
            // 
            this.bt_logout2.Location = new System.Drawing.Point(153, 12);
            this.bt_logout2.Name = "bt_logout2";
            this.bt_logout2.Size = new System.Drawing.Size(75, 23);
            this.bt_logout2.TabIndex = 20;
            this.bt_logout2.Text = "Log Out";
            this.bt_logout2.UseVisualStyleBackColor = true;
            // 
            // pn_kotak3
            // 
            this.pn_kotak3.Controls.Add(this.lb_uang1);
            this.pn_kotak3.Location = new System.Drawing.Point(240, 55);
            this.pn_kotak3.Name = "pn_kotak3";
            this.pn_kotak3.Size = new System.Drawing.Size(252, 164);
            this.pn_kotak3.TabIndex = 21;
            // 
            // pn_kotak4
            // 
            this.pn_kotak4.Controls.Add(this.bt_logout2);
            this.pn_kotak4.Location = new System.Drawing.Point(240, 226);
            this.pn_kotak4.Name = "pn_kotak4";
            this.pn_kotak4.Size = new System.Drawing.Size(252, 135);
            this.pn_kotak4.TabIndex = 22;
            // 
            // lb_uang1
            // 
            this.lb_uang1.AutoSize = true;
            this.lb_uang1.Location = new System.Drawing.Point(109, 74);
            this.lb_uang1.Name = "lb_uang1";
            this.lb_uang1.Size = new System.Drawing.Size(0, 13);
            this.lb_uang1.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_judul);
            this.Controls.Add(this.tb_uang2);
            this.Controls.Add(this.bt_deposit2);
            this.Controls.Add(this.bt_withdraw);
            this.Controls.Add(this.bt_deposit1);
            this.Controls.Add(this.lb_balance);
            this.Controls.Add(this.bt_logout1);
            this.Controls.Add(this.bt_regis1);
            this.Controls.Add(this.tb_user2);
            this.Controls.Add(this.lb_pass1);
            this.Controls.Add(this.lb_user1);
            this.Controls.Add(this.tb_pass2);
            this.Controls.Add(this.bt_login);
            this.Controls.Add(this.pn_kotak1);
            this.Controls.Add(this.pn_kotak2);
            this.Controls.Add(this.pn_kotak3);
            this.Controls.Add(this.pn_kotak4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pn_kotak1.ResumeLayout(false);
            this.pn_kotak1.PerformLayout();
            this.pn_kotak3.ResumeLayout(false);
            this.pn_kotak3.PerformLayout();
            this.pn_kotak4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.TextBox tb_pass2;
        private System.Windows.Forms.Label lb_user1;
        private System.Windows.Forms.Label lb_pass1;
        private System.Windows.Forms.Label lb_pass2;
        private System.Windows.Forms.Label lb_user2;
        private System.Windows.Forms.TextBox tb_user2;
        private System.Windows.Forms.TextBox tb_pass1;
        private System.Windows.Forms.TextBox tb_user1;
        private System.Windows.Forms.Button bt_regis1;
        private System.Windows.Forms.Button bt_regis2;
        private System.Windows.Forms.Panel pn_kotak1;
        private System.Windows.Forms.Panel pn_kotak2;
        private System.Windows.Forms.Button bt_logout1;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Button bt_deposit1;
        private System.Windows.Forms.Button bt_withdraw;
        private System.Windows.Forms.Button bt_deposit2;
        private System.Windows.Forms.TextBox tb_uang2;
        private System.Windows.Forms.Label lb_judul;
        private System.Windows.Forms.Button bt_logout2;
        private System.Windows.Forms.Panel pn_kotak3;
        private System.Windows.Forms.Panel pn_kotak4;
        private System.Windows.Forms.Label lb_uang1;
    }
}

